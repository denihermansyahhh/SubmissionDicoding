package com.denihermansyah.spekhape;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toolbar;

public class DetailHape extends AppCompatActivity {
    Toolbar back;
    ImageView hapeImages;
    TextView hapeNames, hapeDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_hape);

        hapeImages = findViewById(R.id.img_item_photo);
        hapeNames = findViewById(R.id.tv_item_name);
        hapeDetails = findViewById(R.id.tv_item_detail);

        back = findViewById(R.id.toolbarback);
        setSupportActionBar(back);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        int photo = getIntent().getIntExtra("hapeImages", 0);
        String nama = getIntent().getStringExtra("hapeNames");
        String deskripsi = getIntent().getStringExtra("hapeDetails");
        hapeImages.setImageResource(photo);
        hapeNames.setText(nama);
        hapeDetails.setText(deskripsi);
    }

    private void setSupportActionBar(Toolbar back) {
    }
}
