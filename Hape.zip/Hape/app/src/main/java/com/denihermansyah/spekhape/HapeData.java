package com.denihermansyah.spekhape;

import java.util.ArrayList;

public class HapeData {
    private static String[] hapeNames = {
            "Iphone 11 pro",
            "Iphone 9",
            "Samsung s10+",
            "Samsung m50",
            "Realme 5 pro",
            "Vivo v17 pro",
            "Xiaomi Redmi Note 8 pro",
            "Xiaomi Redmi Note 7",
            "Huawei Nova 5 pro",
            "Huawei p20"
    };

    private static String[] hapeDetails = {
            "Spesifikasi Iphone 11 pro\n" +
                    "- Layar 5,8 inci OLED\n" +
                    "- CPU Apple A13 Bionic\n" +
                    "- RAM 6 GB\n" +
                    "- Memori internal 64/256/512 GB\n" +
                    "- Kamera belakang tiga 12 MP (f/1.8 wide + f/2.0 telephoto + f/2.4 ultra-wide)\n" +
                    "- OIS, PDAF, Quad-LED dual-tone flash, 2x optical zoom\n" +
                    "- Kamera depan 12 MP (f/2.2) dan TOF 3D\n" +
                    "- Dual SIM card, dual standby\n" +
                    "- IP68 tahan air dan debu\n" +
                    "- OS iOS 13\n" +
                    "- Baterai 3.190 mAh\n" +
                    "- Face ID, Wireless charging\n" +
                    "- Warna Space Gray, Silver, Gold, Midnight Green" ,
            "Spesifikasi Iphone 9\n" +
                    "- Jaringan 3G, HSPA, EDGE, 4G LTE Cat 9\n" +
                    "- Single SIM, Nano SIM\n" +
                    "- Fitur IP67\n" +
                    "- LED Notifikasi Ada\n" +
                    "- Layar 5.28 inchi, OLED Capacitive\n" +
                    "- Resolusi 1080 x 1920 pixels\n" +
                    "- Ion-strengthened glass, oleophobic coating.\n" +
                    "- Sistem Operasi iOS 11\n" +
                    "- Chipset Apple A10 Fusion\n" +
                    "- CPU Quad-core 2.34 GHz (2x Hurricane + 2x Zephyr)\n" +
                    "- GPU PowerVR Series7XT Plus\n" +
                    "- RAM 4 GB\n" +
                    "- Memori Internal 64/128 /256 GB\n" +
                    "- Memori Eksternal : Tidak ada\n" +
                    "- Kamera Kamera Utama Dual 12 MP, PD Autofocus, OIS, Dual-LED flash\n" +
                    "- Video : 2160p@30fps\n" +
                    "- Kamera Depan 8 MP\n" +
                    "- Konektifitas WIFI, 802 .11 a/ b/g/n\n" +
                    "- Dual-Band\n" +
                    "- WI-FI hotspot\n" +
                    "- Bluetooth v4.2 ,A2DP\n" +
                    "- GPS – A GPS\n" +
                    "- Micro USB v 2.0\n" +
                    "- USB OTG\n" +
                    "- Sensor Fingerprint\n" +
                    "- Acelerometer, Proximity, Gyrocope, Compass\n" +
                    "- Baterai Li-Ion 3000 mAh Non-Removable\n" +
                    "- Fast Charging\n" +
                    "- Warna Hitam, Putih",
            "Spesifikasi Samsung s10+\n" +
                    "- Layar 6,4 inci Quad HD (3.040x1.440) + Curved Dynamic AMOLED, rasio layar 19:9, 438ppi\n" +
                    "- SIM Dual SIM (Hybrid SIM): Nano SIM + Nano SIM or MicroSD slot\n" +
                    "- Konektor USB Type-C, Audio jack 3,5 mm\n" +
                    "- CPU Exynos 9820 (Indonesia) atau Snapdragon 855, 8 nm, 64-bit, Octa-core processor (2,8/2,7 GHz + 2,4/2,3 GHz +1,7/1,9 GHz)\n" +
                    "- RAM/memori RAM 8 GB atau 12 GB (LPDDR4X)/Memori 128 GB/512GB/1TB + up to 512 GB via microSD card\n" +
                    "- Sensor Accelerometer, Barometer, Ultrasonic Fingerprint sensor, Gyro sensor, Geomagnetic sensor, Hall sensor, Heart Rate sensor, Proximity sensor, RGB Light sensor\n" +
                    "- Kamera utama Triple camera with Dual OIS - Telephoto 12MP AF f/1,4, OIS (45 derajat), - Wide-angle 12MP 2PD AF f/1,5 & f/2,4, OIS (77 derajat), - Ultra-Wide 16MP FF, f/2.2 (123 derajat)\n" +
                    "- Kamera depan Dual Camera - Selfie: 10 MP 2PD AF, f/1,9 (80 derajat), - RGB Depth: 8MP FF, f/2.2 (90 derajat)\n" +
                    "- Fitur AR Emoji, Artistic Live Focus, Smart Composition, Scene Optimizer, Super Slow-mo, HDR 10+ playback, Dolby Atmos sound\n" +
                    "- Konektivitas Bluetooth 5.0, NFC, Enhanced 4x4 MIMO, up to 7CA, LAA, LTE Cat.20 - 2.0Gbps download, 150Mbps upload\n" +
                    "- Baterai 4.100 mAh/fast wireless charging 2.0, Wireless PowerShare\n" +
                    "- Anti-air IP68\n" +
                    "- Sistem operasi Samsung OneUI berbasis Android 9 Pie",
            "Spesifikasi Samsung m50\n" +
                    "- Teknologi dan Jaringan.\n" +
                    "- GPRS Yes, EDGE Yes, 4G bands LTE band 1(2100), 3(1800), 5(850), 7(2600), 8(900), 20(800), 38(2600), 40(2300), 41(2500), 3G bands HSDPA 850 / 900 / 1900 / 2100, 2G bands GSM 850 / 900 / 1800 / 1900 - SIM 1 & SIM 2 (dual-SIM model only), GSM / HSPA / LTE\n" +
                    "- Single SIM (Nano-SIM) or Dual SIM (Nano-SIM, dual stand-by)\n" +
                    "- Type Super AMOLED capacitive touchscreen, 16M warna\n" +
                    "- Resolusi  1080 x 2340 pixels, 19.5:9 ratio (~403 ppi density)\n" +
                    "- Proteksi Corning Gorilla Glass 3\n" +
                    "- OS Android 9.0 (Pie)\n" +
                    "- CPU Octa-core (4x2.3 GHz Cortex-A73 & 4x1.7 GHz Cortex-A53)\n" +
                    "- GPU Mali-G72 MP3\n" +
                    "- Chipset Exynos 9610 (10nm)\n" +
                    "- Memory External Bisa di Upgrade dengan microSD, hingga 512 GB (dedicated slot).\n" +
                    "- Memori Internal 64 RAM 4GB Dan 128  RAM 6 GB\n" +
                    "- Kamera Utama Triple 25 MP, f/1.7, PDAF, 8 MP, f/2.2, 12mm (ultrawide), 5 MP, f/2.2, sebagai sensor kedalaman. \n" +
                    "- Dilengkapi dengan LED flash, panorama, HDR\n" +
                    "- Video 1080p@30fps\n" +
                    "- Selfie Kamera Single 25 MP, f/2.0, Features HDR, Kualitas Video 1080p@30fps\n" +
                    "- Active noise cancellation with dedicated mic\n" +
                    "- Sensors Fingerprint (under display), accelerometer, gyro, proximity, compass. \n" +
                    "- Baterai Non removable dengan tipe  Non-removable Li-po 4000 mAh.\n" +
                    "- Pengisian day Fast battery charging 15W",
            "Spesifikasi Realme 5 pro\n" +
                    "- Layar 6,3 inci, IPS LCD, Resolusi 1080 x 2340\n" +
                    "- SoC Snapdragon 712 Octa-core (2x2.3 GHz Kryo 360 Gold & 6x1.7 GHz Kryo 360 Silver), Adreno 616\n" +
                    "- RAM 4 GB 8 GB\n" +
                    "- ROM 128 GB ekspansi hingga 256 GB dengan microSD (dedicated)\n" +
                    "- Kamera Belakang 48 MP, f/1.8, (wide) 8 MP, f/2.2, 13mm (ultrawide) 2 MP, f/2.4, kamera macro 2 MP, f/2.4, depth sensor\n" +
                    "- Kamera Depan 16 MP, f/2.0\n" +
                    "- Baterai 4.035 mAh\n" +
                    "- Sistem Operasi Android 9 Pie",
            "Spesifikasi Vivo v17 pro\n" +
                    "- Layar 6,44 inci, Super AMOLED Resolusi 1080 x 2400 Rasio aspek 20:9\n" +
                    "- Dimensi 159 x 74.7 x 9.8 mm\n" +
                    "- Prosesor Snapdragon 675 Octa-core (2x2.0 GHz Kryo 460 Gold & 6x1.7 GHz Kryo 460 Silver) Adreno 612\n" +
                    "- RAM 8 GB ROM 128 GB, ekspansi 256 GB (microSD)\n" +
                    "- Kamera Belakang 48 megapiksel (f/1.8) 8 megapiksel wide (f/2.2;bidang pandang 120 derajat) 2 megapiksel depth sensor (f/2.4) 2 megapiksel kamera makro (f/2.4)\n" +
                    "- Kamera Depan 32 megapiksel (f/2.0) 8 megapiksel wide (f/2.2; bidang pandang 105 derajat)\n" +
                    "- Baterai 4.100 mAh\n" +
                    "- Konektor USB C\n" +
                    "- Kartu SIM Dual SIM tanpa microSD\n" +
                    "- OS Android 9 Pie + FunTouch OS 9\n" +
                    "- Biometrik Pemindai sidik jari dalam layar (Touch Screen ID)\n" +
                    "- Warna Satin Black Silk White",
            "Spesifikasi Xiaomi Redmi Note 8 pro\n" +
                    "- Ukuran layar IPS LCD 6,53 inci, 1080 x 2340 piksel, rasio 19:9\n" +
                    "- Prosesor CPU: Mediatek Helio G90T, Octa-core (4x2.05 GHz, 4x2.0 GHz); GPU: Mali-G76 MC4\n" +
                    "- RAM 6GB\n" +
                    "- Media penyimpanan 64 GB/128 GB, bisa diperluas dengan kartu microSD hingga 256 GB\n" +
                    "- Kamera belakang 4 Lensa\n" +
                    "- Kamera depan 20 megapiksel, f/2.0\n" +
                    "- Konektor USB Type-C, USB OTG, 3,5mm audio jack\n" +
                    "- Sistem operasi Android Pie 9, MIUI 10",
            "Spesifikasi Xiaomi Redmi Note 7\n" +
                    "- Ukuran display, resolusi 6,3 inch, resolusi 1080 x 2340 pixel, IPS LCD capacitive touchscreen, dengan perlindungan Corning Gorilla Glass 5\n" +
                    "- Dimensi 159.2 x 75.2 x 8.1 mm (6.27 x 2.96 x 0.32 inch)\n" +
                    "- Kamera utama 48 MP, f/1.8, 1/2\", 0.8µm, PDAF 5 MP, f/2.4, depth sensor\n" +
                    "- Kamera depan 13 MP\n" +
                    "- Video 1080p@30fps\n" +
                    "- Prosesor Chipset Qualcomm SDM675 Snapdragon 675 (11 nm)\n" +
                    "- CPU Octa-core (2x2.0 GHz Kryo 460 Gold & 6x1.7 GHz Kryo 460 Silver)\n" +
                    "- GPU Adreno 612\n" +
                    "- Storage 64/128 GB\n" +
                    "- RAM 4/6GB\n" +
                    "- Baterai 4.000 mAh dengan fast charging 18W (Quick Charge 4)\n",
            "Spesifikasi Huawei Nova 5 pro\n" +
                    "- NETWORK\n" +
                    "- 2G bands\tGSM 850 / 900 / 1800 / 1900 – SIM 1 & SIM 2\n" +
                    "- 3G bands\tHSDPA 800 / 850 / 900 / 1700(AWS) / 2100\n" +
                    "- 4G bands\tLTE band 1(2100), 3(1800), 4(1700/2100), 5(850), 8(900), 19(800), 34(2000), 38(2600), 39(1900), 40(2300), 41(2500)\n" +
                    "- BODY\n" +
                    "- Dimensions\t157.4 x 74.8 x 7.3 mm (6.20 x 2.94 x 0.29 in)\n" +
                    "- Weight\t171 g (6.03 oz)\n" +
                    "- Build\t\n" +
                    "- SIM\tHybrid Dual SIM (Nano-SIM, dual stand-by)\n" +
                    "- Colors\tBlack, Purple, Green, Orange\n" +
                    "- DISPLAY\n" +
                    "- Type\tOLED capacitive touchscreen, 16M colors\n" +
                    "- Size\t6.39 inches, 100.2 cm2 (~85.1% screen-to-body ratio)\n" +
                    "- Resolution\t1080 x 2340 pixels, 19.5:9 ratio (~403 ppi density)\n" +
                    "- Protection\t\n" +
                    "- DCI-P3 108%\n" +
                    "- PLATFORM\n" +
                    "- OS\tAndroid 9.0 (Pie), EMUI 9.1\n" +
                    "- Chipset\tHiSilicon Kirin 980 (7 nm)\n" +
                    "- CPU\tOcta-core (2×2.6 GHz Cortex-A76 & 2×1.92 GHz Cortex-A76 & 4×1.8 GHz Cortex-A55)\n" +
                    "- GPU\tMali-G76 MP10\n" +
                    "- MEMORY\n" +
                    "- Card slot\tNM (Nano Memory), up to 256GB (uses shared SIM slot)\n" +
                    "- RAM\t8 GB\n" +
                    "- Internal\t128/256 GB, 8 GB RAM\n" +
                    "- MAIN CAMERA\n" +
                    "- Sensors\t48 MP, f/1.8, 26mm (wide), 1/2″, 0.8µm, PDAF\n" +
                    "- 16 MP, f/2.2, (wide)\n" +
                    "- 2 MP, f/2.4, 27mm (wide) dedicated macro camera\n" +
                    "- 2 MP, f/2.4, depth sensor\n" +
                    "- Features\tLED flash, HDR, panorama\n" +
                    "- Video\t2160p@30fps, 1080p@30fps\n" +
                    "- SELFIE CAMERA\n" +
                    "- Sensors\t32 MP, f/2.0\n" +
                    "- Features\tHDR\n" +
                    "- Video\t1080p@30fps\n" +
                    "- SOUND\n" +
                    "- SOUND\tActive noise cancellation with dedicated mic\n" +
                    "- CONNECTIVITY\n" +
                    "- WLAN\tWi-Fi 802.11 a/b/g/n/ac, dual-band, Wi-Fi Direct, hotspot\n" +
                    "- Bluetooth\t5.0, A2DP, LE, aptX HD\n" +
                    "- GPS\tYes, with A-GPS, GLONASS, BDS\n" +
                    "- NFC\tYes\n" +
                    "- Radio\t\n" +
                    "- USB\t2.0, Type-C 1.0 reversible connector, USB On-The-Go\n" +
                    "- FEATURES\n" +
                    "- Sensors\tFingerprint (under display), accelerometer, gyro, proximity, compass\n" +
                    "- Other\t\n" +
                    "- BATTERY\n" +
                    "- Type\tLi-Po\n" +
                    "- Size\t3500mAh\n" +
                    "- Non-removable Li-Po 3500 mAh battery",
            "Spesifikasi Huawei p20\n" +
                    "- 12 megapixel RGB f/1.8 and 20 megapixel BW f/1.6 dual Leica rear cameras\n" +
                    "- 24 megapixel f/2.0 selfie camera\n" +
                    "- 4D predictive focus\n" +
                    "- 5.8 inch 2244x1080 pixel touchscreen\n" +
                    "- Wi-Fi/NFC/Bluetooth\n" +
                    "- Dual tone LED flash\n" +
                    "- 4K video recording\n" +
                    "- AI smart photo technology identifies the subject you're shooting\n" +
                    "- 3400 mAh battery\n" +
                    "- RAW shooting in Pro mode\n" +
                    "- ISO 50-3200 (Selectable in Pro mode)\n" +
                    "- Fingerprint sensor"
    };

    private static int[] hapeImages = {
            R.drawable.iphone_11_pro,
            R.drawable.iphone9,
            R.drawable.samsung_s10plus,
            R.drawable.samsung_m50,
            R.drawable.realme_5_pro,
            R.drawable.vivo_v17_pro,
            R.drawable.xiaomi_redminote8_pro,
            R.drawable.xiaomi_redminote7,
            R.drawable.huawei_nova_5pro,
            R.drawable.huawei_p20
    };

    static ArrayList<Hape> getListData() {
        ArrayList<Hape> list = new ArrayList<>();
        for (int position = 0; position < hapeNames.length; position++) {
            Hape hape = new Hape();
            hape.setName(hapeNames[position]);
            hape.setDetail(hapeDetails[position]);
            hape.setPhoto(hapeImages[position]);
            list.add(hape);
        }
        return list;
    }
}
